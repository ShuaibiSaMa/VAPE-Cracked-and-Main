# Vape
Open-Source vape client launcher, loader &amp; socket.

Since this repository is more than likely to be taken down under the Digital Millennium Copyright Act, there is no guarantee this source-code will be avaiable in the future.
Archive this work at your will.

## Progress

Vape V4 DLL - Most of the semantics have been translated into source code, it is close to being released.

Vape V4 Launcher - Work has been started, loads the DLL & the DLL communicates back as expected.

Lite DLL - Work not started.

Vape Lite Loader - Tested with official Lite DLL, loads fine. All Lite resource names have been resolved from the dump and the UI is slowly being designed in Figma to be accurate.
