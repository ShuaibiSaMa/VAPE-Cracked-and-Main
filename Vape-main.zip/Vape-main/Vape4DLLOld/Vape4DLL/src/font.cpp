#include "font.h"


// freetype.lib

void Initialize(char* name, int size) {

}