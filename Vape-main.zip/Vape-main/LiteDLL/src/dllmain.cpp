#include "export.h"

// Vape Lite is pretty fucking huge.

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpReserved) {

}