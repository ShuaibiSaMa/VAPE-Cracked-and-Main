#include <Windows.h>

namespace Menu
{
void Theme();
void Render();
} // namespace Menu